"""
Send a WhatsApp message through AWS End User Messaging Social.

Environment variables:
  ORIGINATION_PHONE_NUMBER_ID  e.g. phone-number-id-5a019ac8025448978f5adcbf1d14dbd7
  META_API_VERSION             optional, defaults to v19.0

Event formats:
  Freeform text (only works inside the 24h customer-service window):
    {"to": "+15859107690", "text": "Hello!"}

  Approved template (works any time):
    {"to": "+15859107690",
     "template": {"name": "visit_reminder", "language": "en_US",
                  "parameters": ["Week 4", "9:00 AM"]}}

  Raw WhatsApp message object (buttons, lists, location, images...):
    {"to": "+15859107690", "message": {"type": "interactive", "interactive": {...}}}
"""

import json
import os

import boto3
from botocore.exceptions import ClientError

ORIGINATION_PHONE_NUMBER_ID = os.environ["ORIGINATION_PHONE_NUMBER_ID"]
META_API_VERSION = os.environ.get("META_API_VERSION", "v19.0")

client = boto3.client("socialmessaging")


def build_message(event):
    to = event.get("to")
    if not to:
        raise ValueError("'to' is required, e.g. '+15551234567'")

    if "message" in event:
        # Pass-through for any WhatsApp Cloud API message type
        msg = dict(event["message"])
    elif "template" in event:
        t = event["template"]
        template = {
            "name": t["name"],
            "language": {"code": t.get("language", "en_US")},
        }
        params = t.get("parameters")
        if params:
            template["components"] = [
                {
                    "type": "body",
                    "parameters": [{"type": "text", "text": str(p)} for p in params],
                }
            ]
        msg = {"type": "template", "template": template}
    elif "text" in event:
        msg = {"type": "text", "text": {"body": event["text"]}}
    else:
        raise ValueError("Provide one of 'text', 'template' or 'message'")

    msg["messaging_product"] = "whatsapp"
    msg["to"] = to
    return msg


def lambda_handler(event, context):
    try:
        message = build_message(event)
    except (ValueError, KeyError, TypeError) as e:
        return {"statusCode": 400, "error": str(e)}

    try:
        resp = client.send_whatsapp_message(
            originationPhoneNumberId=ORIGINATION_PHONE_NUMBER_ID,
            # boto3 handles the base64 encoding; just pass raw bytes
            message=json.dumps(message).encode("utf-8"),
            metaApiVersion=META_API_VERSION,
        )
    except ClientError as e:
        err = e.response.get("Error", {})
        print(f"send_whatsapp_message failed: {err}")
        return {
            "statusCode": 500,
            "error": err.get("Code"),
            "detail": err.get("Message"),
        }

    print(f"Sent {message['type']} message to {message['to']}: {resp['messageId']}")
    return {"statusCode": 200, "messageId": resp["messageId"]}